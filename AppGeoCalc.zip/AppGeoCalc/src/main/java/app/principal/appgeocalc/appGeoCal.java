package app.principal.appgeocalc;
import UI.FrmMenuPrincipal;

public class appGeoCal {


    public static void main(String[] args) {
        FrmMenuPrincipal menu = new FrmMenuPrincipal();
        menu.setVisible(true);
    }
    
}


