
package modelo;

public abstract class Poligono {
    private int numerolados;

    public Poligono(int numerolados) {
        this.numerolados = numerolados;
    }
    
    public int getNumeroLados(){
        return numerolados;
    }
    
    public void setNumeroLados(int numerolados){
        this.numerolados = numerolados;
    }
    
    public abstract double area();
    public abstract double perimetro();
}