
package modelo;

public class Trapecio extends Poligono{
    double Base;
    double base;
    double lados;
    double altura;

    public Trapecio(double Base, double base,double lados, double altura, int numerolados) {
        super(numerolados);
        this.Base = Base;
        this.base = base;
        this.lados = lados;
        this.altura = altura;
    }
    
    public double getBase(){
        return Base;
    }
    public double getbase(){
        return base;
    }
    public double getLados(){
        return lados;
    }

    public double getaltura() {
        return altura;
    }
    
    public void setBase(double Base){
        this.Base = Base;
    }
    public void setbase(double base){
        this.base= base;
    }
    public void setLado1(double lados){
        this.lados = lados;
    }
    public void setAltura(double altura){
        this.altura = altura;
    }
    
@Override 

public double area (){
    return ((base+Base)*altura)/2;
    
}
@Override 

public double perimetro(){
    return Base+base+(lados*2);
}
}   
